module.exports = {
  apps: [
    {
      name: 'dg-absen',
      script: 'server.js',
      instances: 1,
      autorestart: true,
      watch: false,
      max_memory_restart: '500M',
      env: {
        NODE_ENV: 'production',
        PORT: process.env.PORT || process.env.SERVER_PORT || 3000,
        HOST: '0.0.0.0'
      }
    }
  ]
};
