// server.ts
import express from "express";
import path from "path";
import fs from "fs";
import { fileURLToPath } from "url";
var __filename = fileURLToPath(import.meta.url);
var __dirname = path.dirname(__filename);
var app = express();
var PORT = Number(process.env.PORT) || Number(process.env.SERVER_PORT) || 3e3;
var HOST = process.env.HOST || "0.0.0.0";
app.use(express.json({ limit: "50mb" }));
app.use(express.urlencoded({ extended: true, limit: "50mb" }));
var DB_FILE = path.join(__dirname, "db.json");
var DEFAULT_DB = {
  shifts: [
    { id: "S1", name: "Shift Pagi (08:00 - 17:00)", startTime: "08:00:00", endTime: "17:00:00" },
    { id: "S2", name: "Shift Siang (13:00 - 22:00)", startTime: "13:00:00", endTime: "22:00:00" },
    { id: "S3", name: "Shift Malam (22:00 - 07:00)", startTime: "22:00:00", endTime: "07:00:00" }
  ],
  employees: [],
  attendanceLogs: [],
  leaveRequests: [],
  storeLocation: {
    name: "DG KOMPUTER HQ",
    address: "Menara BCA Lt. 42, Grand Indonesia, Jakarta Pusat",
    latitude: -6.211774,
    longitude: 106.844226,
    radius: 50,
    isClosed: false
  },
  positions: [],
  alarmSettings: {
    clockInAlarmEnabled: true,
    clockInTime: "07:45",
    clockOutAlarmEnabled: true,
    clockOutTime: "17:00",
    browserNotificationEnabled: true
  },
  fcmTokens: []
};
var db = { ...DEFAULT_DB };
var loadDatabase = () => {
  try {
    if (fs.existsSync(DB_FILE)) {
      const data = fs.readFileSync(DB_FILE, "utf-8");
      const parsed = JSON.parse(data);
      db = {
        ...DEFAULT_DB,
        ...parsed,
        shifts: parsed.shifts || DEFAULT_DB.shifts,
        employees: parsed.employees || DEFAULT_DB.employees,
        attendanceLogs: parsed.attendanceLogs || [],
        leaveRequests: parsed.leaveRequests || DEFAULT_DB.leaveRequests,
        storeLocation: parsed.storeLocation || DEFAULT_DB.storeLocation,
        positions: parsed.positions || DEFAULT_DB.positions,
        alarmSettings: parsed.alarmSettings || DEFAULT_DB.alarmSettings,
        fcmTokens: parsed.fcmTokens || []
      };
    } else {
      saveDatabase();
    }
  } catch (err) {
    console.error("Failed to load db.json, using default database:", err);
  }
};
var saveDatabase = () => {
  try {
    fs.writeFileSync(DB_FILE, JSON.stringify(db, null, 2), "utf-8");
  } catch (err) {
    console.error("Failed to save db.json:", err);
  }
};
loadDatabase();
var sseClients = [];
var broadcastEvent = (data) => {
  const message = `data: ${JSON.stringify(data)}

`;
  sseClients.forEach((client) => {
    try {
      client.res.write(message);
    } catch {
    }
  });
};
setInterval(() => {
  broadcastEvent({ type: "heartbeat", timestamp: Date.now() });
}, 15e3);
app.get("/api/health", (_req, res) => {
  res.json({ status: "ok", serverTime: (/* @__PURE__ */ new Date()).toISOString() });
});
app.get("/api/events", (req, res) => {
  res.writeHead(200, {
    "Content-Type": "text/event-stream",
    "Cache-Control": "no-cache, no-transform",
    "Connection": "keep-alive",
    "X-Accel-Buffering": "no",
    "Access-Control-Allow-Origin": "*"
  });
  const clientId = `client-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`;
  const newClient = { id: clientId, res };
  sseClients.push(newClient);
  res.write(`data: ${JSON.stringify({ type: "connected", clientId })}

`);
  req.on("close", () => {
    sseClients = sseClients.filter((c) => c.id !== clientId);
  });
});
app.post("/api/broadcast", (req, res) => {
  const { event, payload } = req.body;
  broadcastEvent({
    type: "broadcast",
    event,
    payload
  });
  res.json({ success: true });
});
app.get("/api/places/search", async (req, res) => {
  const query = String(req.query.q || "").trim();
  if (!query) {
    return res.json({ results: [] });
  }
  const coordRegex = /[-+]?([1-8]?\d(\.\d+)?|90(\.0+)?),\s*[-+]?(180(\.0+)?|((1[0-7]\d)|([1-9]?\d))(\.\d+)?)/;
  const match = query.match(coordRegex);
  if (match) {
    const parts = match[0].split(",").map((s) => parseFloat(s.trim()));
    if (parts.length === 2 && !isNaN(parts[0]) && !isNaN(parts[1])) {
      return res.json({
        results: [
          {
            id: "coords-result",
            name: `Titik Koordinat GPS (${parts[0].toFixed(6)}, ${parts[1].toFixed(6)})`,
            address: `Koordinat presisi terdeteksi dari pencarian`,
            lat: parts[0],
            lng: parts[1],
            source: "coordinate"
          }
        ]
      });
    }
  }
  const apiKey = process.env.VITE_GOOGLE_MAPS_API_KEY || "AIzaSyADiI4JaybcerL6GyNPuHnFt3ml-EA6jKE";
  if (apiKey) {
    try {
      const gRes = await fetch("https://places.googleapis.com/v1/places:searchText", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "X-Goog-Api-Key": apiKey,
          "X-Goog-FieldMask": "places.id,places.displayName,places.formattedAddress,places.location",
          "X-Goog-Maps-Solution-ID": "gmp_mcp_codeassist_v1_aistudio"
        },
        body: JSON.stringify({
          textQuery: query,
          languageCode: "id",
          regionCode: "ID"
        })
      });
      if (gRes.ok) {
        const data = await gRes.json();
        if (data.places && data.places.length > 0) {
          const results = data.places.map((p) => ({
            id: p.id,
            name: p.displayName?.text || query,
            address: p.formattedAddress || "",
            lat: p.location?.latitude,
            lng: p.location?.longitude,
            source: "google_places"
          }));
          return res.json({ results });
        }
      }
    } catch (err) {
      console.warn("Google Places API search failed, falling back:", err);
    }
  }
  try {
    const osmRes = await fetch(
      `https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(query)}&limit=5&countrycodes=id&addressdetails=1`,
      { headers: { "User-Agent": "DG-Komputer-Attendance-App/1.0" } }
    );
    if (osmRes.ok) {
      const osmData = await osmRes.json();
      const results = osmData.map((item) => ({
        id: item.place_id ? String(item.place_id) : Math.random().toString(),
        name: item.name || item.display_name?.split(",")[0] || query,
        address: item.display_name || "",
        lat: parseFloat(item.lat),
        lng: parseFloat(item.lon),
        source: "osm"
      }));
      return res.json({ results });
    }
  } catch (err) {
    console.error("OSM fallback search error:", err);
  }
  return res.json({ results: [] });
});
app.get("/api/employees", (_req, res) => {
  res.json(db.employees);
});
app.post("/api/employees", (req, res) => {
  const emp = req.body;
  if (!emp || !emp.id) {
    return res.status(400).json({ error: "Employee id is required" });
  }
  const index = db.employees.findIndex((e) => e.id === emp.id);
  if (index >= 0) {
    db.employees[index] = { ...db.employees[index], ...emp };
  } else {
    db.employees.push(emp);
  }
  saveDatabase();
  broadcastEvent({
    type: "postgres_changes",
    table: "employees",
    event: "*"
  });
  res.json({ success: true, employee: emp });
});
app.delete("/api/employees/:id", (req, res) => {
  const { id } = req.params;
  db.employees = db.employees.filter((e) => e.id !== id);
  saveDatabase();
  broadcastEvent({
    type: "postgres_changes",
    table: "employees",
    event: "*"
  });
  res.json({ success: true });
});
app.delete("/api/employees", (_req, res) => {
  db.employees = [];
  saveDatabase();
  broadcastEvent({
    type: "postgres_changes",
    table: "employees",
    event: "*"
  });
  res.json({ success: true });
});
app.get("/api/logs", (_req, res) => {
  res.json(db.attendanceLogs);
});
app.post("/api/logs", (req, res) => {
  const log = req.body;
  if (!log || !log.id) {
    return res.status(400).json({ error: "Log id is required" });
  }
  const index = db.attendanceLogs.findIndex((l) => l.id === log.id);
  if (index >= 0) {
    db.attendanceLogs[index] = { ...db.attendanceLogs[index], ...log };
  } else {
    db.attendanceLogs.unshift(log);
  }
  saveDatabase();
  broadcastEvent({
    type: "postgres_changes",
    table: "attendance_logs",
    event: "*"
  });
  res.json({ success: true, log });
});
app.delete("/api/logs/:id", (req, res) => {
  const { id } = req.params;
  db.attendanceLogs = db.attendanceLogs.filter((l) => l.id !== id);
  saveDatabase();
  broadcastEvent({
    type: "postgres_changes",
    table: "attendance_logs",
    event: "*"
  });
  res.json({ success: true });
});
app.delete("/api/logs", (_req, res) => {
  db.attendanceLogs = [];
  saveDatabase();
  broadcastEvent({
    type: "postgres_changes",
    table: "attendance_logs",
    event: "*"
  });
  res.json({ success: true });
});
app.get("/api/leaves", (_req, res) => {
  res.json(db.leaveRequests);
});
app.post("/api/leaves", (req, res) => {
  const leave = req.body;
  if (!leave || !leave.id) {
    return res.status(400).json({ error: "Leave request id is required" });
  }
  const index = db.leaveRequests.findIndex((l) => l.id === leave.id);
  if (index >= 0) {
    db.leaveRequests[index] = { ...db.leaveRequests[index], ...leave };
  } else {
    db.leaveRequests.unshift(leave);
  }
  saveDatabase();
  broadcastEvent({
    type: "postgres_changes",
    table: "leave_requests",
    event: "*"
  });
  res.json({ success: true, leave });
});
app.delete("/api/leaves", (_req, res) => {
  db.leaveRequests = [];
  saveDatabase();
  broadcastEvent({
    type: "postgres_changes",
    table: "leave_requests",
    event: "*"
  });
  res.json({ success: true });
});
app.get("/api/store-location", (_req, res) => {
  res.json(db.storeLocation);
});
app.post("/api/store-location", (req, res) => {
  const loc = req.body;
  db.storeLocation = { ...db.storeLocation, ...loc };
  saveDatabase();
  broadcastEvent({
    type: "postgres_changes",
    table: "store_location",
    event: "*"
  });
  res.json({ success: true, location: db.storeLocation });
});
app.get("/api/positions", (_req, res) => {
  res.json(db.positions || []);
});
app.post("/api/positions", (req, res) => {
  const { name } = req.body;
  if (name && typeof name === "string") {
    const trimmed = name.trim();
    if (!db.positions) db.positions = [];
    if (trimmed && !db.positions.includes(trimmed)) {
      db.positions.push(trimmed);
      saveDatabase();
    }
  }
  res.json({ success: true, positions: db.positions });
});
app.put("/api/positions", (req, res) => {
  const { positions } = req.body;
  if (Array.isArray(positions)) {
    db.positions = positions.map((p) => String(p).trim()).filter(Boolean);
    saveDatabase();
  }
  res.json({ success: true, positions: db.positions });
});
app.put("/api/positions/:oldName", (req, res) => {
  const { oldName } = req.params;
  const { newName } = req.body;
  if (newName && typeof newName === "string") {
    const trimmed = newName.trim();
    if (!db.positions) db.positions = [];
    const idx = db.positions.indexOf(oldName);
    if (idx !== -1) {
      db.positions[idx] = trimmed;
    } else if (!db.positions.includes(trimmed)) {
      db.positions.push(trimmed);
    }
    db.employees.forEach((emp) => {
      if (emp.role === oldName) {
        emp.role = trimmed;
      }
    });
    saveDatabase();
  }
  res.json({ success: true, positions: db.positions });
});
app.delete("/api/positions/:name", (req, res) => {
  const { name } = req.params;
  if (db.positions) {
    db.positions = db.positions.filter((p) => p !== name);
    saveDatabase();
  }
  res.json({ success: true, positions: db.positions });
});
app.get("/api/alarm-settings", (_req, res) => {
  res.json(db.alarmSettings);
});
app.post("/api/alarm-settings", (req, res) => {
  const settings = req.body;
  db.alarmSettings = { ...db.alarmSettings, ...settings };
  saveDatabase();
  res.json({ success: true, alarmSettings: db.alarmSettings });
});
app.get("/api/fcm-tokens", (req, res) => {
  const { employeeId } = req.query;
  if (employeeId) {
    const tokens = db.fcmTokens.filter((t) => t.employeeId === employeeId).map((t) => t.token);
    return res.json(tokens);
  }
  res.json(db.fcmTokens.map((t) => t.token));
});
app.post("/api/fcm-tokens", (req, res) => {
  const { employeeId, token } = req.body;
  if (employeeId && token) {
    const existing = db.fcmTokens.find((t) => t.employeeId === employeeId && t.token === token);
    if (!existing) {
      db.fcmTokens.push({ employeeId, token, updatedAt: (/* @__PURE__ */ new Date()).toISOString() });
      saveDatabase();
    }
  }
  res.json({ success: true });
});
app.delete("/api/fcm-tokens", (req, res) => {
  const { token } = req.query;
  if (token) {
    db.fcmTokens = db.fcmTokens.filter((t) => t.token !== token);
    saveDatabase();
  }
  res.json({ success: true });
});
app.get("/api/shifts", (_req, res) => {
  res.json(db.shifts);
});
async function startServer() {
  const isProduction = process.env.NODE_ENV === "production";
  if (!isProduction) {
    const { createServer: createViteServer } = await import("vite");
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa"
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(__dirname, "dist");
    if (fs.existsSync(distPath) && fs.existsSync(path.join(distPath, "index.html"))) {
      app.use(express.static(distPath));
      app.get("*", (_req, res) => {
        res.sendFile(path.join(distPath, "index.html"));
      });
    } else {
      console.warn(`[WARN] 'dist' folder not found at ${distPath}. Falling back to Vite development middleware...`);
      const { createServer: createViteServer } = await import("vite");
      const vite = await createViteServer({
        server: { middlewareMode: true },
        appType: "spa"
      });
      app.use(vite.middlewares);
    }
  }
  const server = app.listen(PORT, HOST, () => {
    console.log(`Dg-Absen Server running on http://${HOST}:${PORT}`);
  });
  const handleShutdown = () => {
    console.log("Shutting down server gracefully...");
    server.close(() => {
      console.log("Server shut down cleanly.");
      process.exit(0);
    });
  };
  process.on("SIGTERM", handleShutdown);
  process.on("SIGINT", handleShutdown);
}
startServer();
