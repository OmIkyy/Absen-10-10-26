# Sistem Absensi Karyawan DG-Komputer 🏢

Aplikasi Presensi Karyawan Terintegrasi berbasis Web (GPS Radius, Kamera Selfie Masuk/Pulang, Pengajuan Izin/Cuti, Manajemen Shift, Rekap Excel, dan Notifikasi Real-time) dengan backend Node.js Express mandiri dan database server persisten (`db.json`).

---

## 📋 Daftar Isi
1. [Fitur Utama](#fitur-utama)
2. [Persyaratan Sistem](#persyaratan-sistem)
3. [Instalasi Awal](#instalasi-awal)
4. [Mode Pengembangan (Development)](#mode-pengembangan-development)
5. [Mode Produksi dengan PM2](#mode-produksi-dengan-pm2)
6. [Daftar Perintah PM2 (Start, Stop, Restart, dll.)](#daftar-perintah-pm2)
7. [Solusi Error Umum (Troubleshooting)](#solusi-error-umum-troubleshooting)
8. [Konfigurasi Port & Nginx Reverse Proxy](#konfigurasi-port--nginx-reverse-proxy)
9. [Akses Panel Admin](#akses-panel-admin)
10. [Cadangan & Lokasi Database](#cadangan--lokasi-database)

---

## ✨ Fitur Utama
- **Presensi GPS & Foto Selfie**: Validasi radius koordinat kantor DG Komputer dengan kamera selfie real-time.
- **Penyimpanan Server Lokal (`db.json`)**: Tidak memerlukan Supabase atau database eksternal. Semua tersimpan di server sendiri.
- **Sinkronisasi Real-time (SSE)**: Perubahan data, absen karyawan, dan permohonan izin langsung tersinkron ke semua perangkat (HP & PC) seketika.
- **Indikator Status Sinkronisasi**: Deteksi otomatis **Online** (hijau) atau **Off** (merah) dengan auto-reconnect.
- **Dukungan Penuh PM2**: Siap dijalankan di VPS / server produksi dengan auto-restart dan pemantauan memori.

---

## ⚙️ Persyaratan Sistem
- **Node.js**: Versi `18.x`, `20.x`, atau `22.x` (LTS direkomendasikan)
- **NPM**: Versi `9.x` atau lebih baru
- **PM2**: Diinstal secara global (`npm install -g pm2`)
- **OS**: Linux (Ubuntu/Debian/CentOS), macOS, atau Windows

---

## 🚀 Instalasi Awal
Clone atau unggah repositori ke server Anda, kemudian masuk ke direktori proyek dan instal dependensi:

```bash
# Masuk ke direktori aplikasi
cd /path/to/applet

# Install semua dependensi
npm install

# Install PM2 secara global jika belum terpasang
npm install -g pm2
```

---

## 💻 Mode Pengembangan (Development)
Untuk menguji dan mengembangkan aplikasi secara lokal:

```bash
npm run dev
```
Aplikasi akan berjalan pada `http://localhost:3000`.

---

## 🛡️ Mode Produksi dengan PM2

Sebelum menjalankan di server produksi, Anda **wajib menjalankan build** terlebih dahulu agar folder antarmuka (`dist/`) dan file server (`server.js`) terkompilasi:

```bash
# 1. Kompilasi frontend dan backend
npm run build

# 2. Jalankan aplikasi menggunakan PM2
npm run pm2:start
# Atau gunakan perintah PM2 langsung:
pm2 start ecosystem.config.cjs
```

---

## 📌 Daftar Perintah PM2

Berikut daftar perintah yang dapat Anda gunakan untuk mengelola proses server:

| Aksi | Perintah NPM Shortcut | Perintah PM2 Langsung | Keterangan |
| :--- | :--- | :--- | :--- |
| **Menjalankan Server** | `npm run pm2:start` | `pm2 start ecosystem.config.cjs` | Menjalankan aplikasi di background |
| **Menghentikan Server (Stop)** | `npm run pm2:stop` | `pm2 stop dg-absen` | Menghentikan sementara aplikasi |
| **Memulai Ulang (Restart)** | `npm run pm2:restart` | `pm2 restart dg-absen` | Merestart aplikasi (misal setelah edit data) |
| **Melihat Log Real-time** | `npm run pm2:logs` | `pm2 logs dg-absen` | Menampilkan log error dan output server |
| **Menghapus dari PM2** | `npm run pm2:delete` | `pm2 delete dg-absen` | Menghapus proses dari daftar PM2 |
| **Cek Status Aplikasi** | - | `pm2 status` | Melihat status, uptime, memori, & CPU |
| **Monitor Dashboard PM2** | - | `pm2 monit` | Tampilan monitor CPU & RAM interaktif |
| **Simpan Konfigurasi Reboot** | - | `pm2 save` | Menyimpan daftar proses agar tidak hilang |
| **Auto-start Saat Boot Server**| - | `pm2 startup` | Menjalankan PM2 otomatis saat OS restart |

---

## 🔧 Solusi Error Umum (Troubleshooting)

### 1. Error: `Error: listen EADDRINUSE: address already in use :::3000`
**Penyebab**: Port 3000 sedang digunakan oleh aplikasi lain atau proses node lama yang belum ditutup.
**Solusi**:
- Cek dan hentikan proses di port 3000:
  ```bash
  # Linux / Ubuntu:
  sudo fuser -k 3000/tcp
  # Atau cari PID:
  lsof -i :3000
  kill -9 <PID>
  ```
- Atau ganti port di file `ecosystem.config.cjs`:
  ```javascript
  env: {
    PORT: 3001
  }
  ```
  Lalu jalankan ulang `pm2 restart dg-absen`.

---

### 2. Error: `ENOENT: no such file or directory, stat '.../dist/index.html'`
**Penyebab**: Aplikasi dijalankan sebelum proses build frontend selesai.
**Solusi**:
Jalankan build terlebih dahulu:
```bash
npm run build
pm2 restart dg-absen
```

---

### 3. Error: `pm2: command not found`
**Penyebab**: PM2 belum terinstal secara global atau path npm belum terdaftar di environment OS.
**Solusi**:
```bash
sudo npm install -g pm2
```
Jika menggunakan `nvm`:
```bash
nvm use default
npm install -g pm2
```

---

### 4. Status Menunjukkan "Database Off (Offline)" di Web
**Penyebab**:
- Server backend sedang mati / dihentikan (`pm2 stop`).
- Firewall server memblokir akses ke port 3000.
- Browser pengguna offline / tidak ada internet.
**Solusi**:
- Pastikan status PM2 dalam kondisi `online`: `pm2 status`
- Buka port firewall (misal UFW di Ubuntu): `sudo ufw allow 3000/tcp`
- Periksa log error: `pm2 logs dg-absen --lines 50`

---

## 🌐 Konfigurasi Nginx Reverse Proxy (Opsional)

Jika Anda menggunakan domain pribadi (misalnya `absen.perusahaan.com`) dengan SSL HTTPS:

```nginx
server {
    server_name absen.perusahaan.com;

    location / {
        proxy_pass http://127.0.0.1:3000;
        proxy_http_version 1.1;
        
        # Pengaturan penting untuk Real-time SSE (Server-Sent Events)
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
        
        proxy_buffering off;
        proxy_read_timeout 86400s;
        proxy_send_timeout 86400s;
        proxy_set_header X-Accel-Buffering no;
    }
}
```

---

## 🔑 Akses Panel Admin

1. Buka aplikasi di peramban (browser).
2. Klik tombol **"Dashboard Admin"** pada bilah navigasi kanan atas (atau akses melalui alamat URL dengan menambahkan `#admin` di belakang link, contoh: `https://domain-anda.com/#admin`).
3. Masukkan kredensial admin:
   - **Username**: `admin`
   - **Password**: `admin123`

*(Kredensial username dan password dapat diganti kapan saja melalui tab Pengaturan Admin di dalam dashboard).*

---

## 💾 Cadangan & Lokasi Database

Semua data (daftar karyawan, log selfie/GPS absensi, izin cuti, lokasi kantor, shift kerja) disimpan secara persisten di dalam file:
```
db.json
```
Untuk membuat cadangan (backup) data:
```bash
cp db.json db_backup_$(date +%F).json
```
Untuk mengembalikan data dari cadangan:
```bash
cp db_backup_2026-10-04.json db.json
pm2 restart dg-absen
```
