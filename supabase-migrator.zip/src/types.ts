export interface Shift {
  id: string;
  name: string;
  startTime: string;
  endTime: string;
}

export const SHIFTS: Shift[] = [
  { id: 'S1', name: 'Shift Pagi (08:00 - 17:00)', startTime: '08:00:00', endTime: '17:00:00' },
  { id: 'S2', name: 'Shift Siang (13:00 - 22:00)', startTime: '13:00:00', endTime: '22:00:00' },
  { id: 'S3', name: 'Shift Malam (22:00 - 07:00)', startTime: '22:00:00', endTime: '07:00:00' }
];

export interface Employee {
  id: string;
  name: string;
  role: string;
  department: string;
  avatar: string;
  phone: string;
  activeShiftId: string;
  nik?: string;
  ktpPhoto?: string;
}

export interface AttendanceLog {
  id: string;
  employeeId: string;
  employeeName: string;
  date: string;
  shiftId: string;
  shiftName: string;
  clockIn: string;
  clockOut?: string;
  breakStart?: string;
  breakEnd?: string;
  status: string; // 'Masuk' | 'Pulang' | 'Terlambat' | 'Izin' | 'Cuti' | 'Sakit'
  notes?: string;
  selfieUrl?: string;
  latitude?: number;
  longitude?: number;
  address?: string;
  workingHours?: number;
}

export interface LeaveRequest {
  id: string;
  employeeId: string;
  employeeName: string;
  type: string; // 'Cuti' | 'Sakit' | 'Izin'
  startDate: string;
  endDate: string;
  reason: string;
  status: string; // 'Pending' | 'Disetujui' | 'Ditolak'
  createdAt: string;
  attachmentUrl?: string;
}

export interface StoreLocation {
  name: string;
  address: string;
  latitude: number;
  longitude: number;
  radius: number;
  isClosed?: boolean;
}

export interface AdminNotification {
  id: string;
  employeeName?: string;
  type: 'clock_in' | 'clock_out' | 'break_start' | 'break_end' | 'leave' | 'info' | 'warning' | string;
  time?: string;
  date?: string;
  title?: string;
  message?: string;
  timestamp: number;
  read: boolean;
}

export const DEFAULT_STORE_LOCATION: StoreLocation = {
  name: 'DG KOMPUTER HQ',
  address: 'Menara BCA Lt. 42, Grand Indonesia, Jakarta Pusat',
  latitude: -6.211774,
  longitude: 106.844226,
  radius: 50,
  isClosed: false
};

export const SAMPLE_EMPLOYEES: Employee[] = [];

export const SAMPLE_LEAVES: LeaveRequest[] = [];

export const generateSampleLogs = (): AttendanceLog[] => [];
