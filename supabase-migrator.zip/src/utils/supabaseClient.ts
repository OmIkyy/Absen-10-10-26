import { Employee, AttendanceLog, LeaveRequest, StoreLocation } from '../types';

export interface DbAlarmSettings {
  clockInAlarmEnabled: boolean;
  clockInTime: string;
  clockOutAlarmEnabled: boolean;
  clockOutTime: string;
  browserNotificationEnabled: boolean;
}

// Server connection and status listeners
export type ConnectionStatus = 'online' | 'offline';
const statusListeners: Array<(status: ConnectionStatus) => void> = [];
let currentServerStatus: ConnectionStatus = 'online';

export const isSupabaseConfigured = (): boolean => {
  return true;
};

export const getServerConnectionStatus = (): ConnectionStatus => {
  return currentServerStatus;
};

export const onServerStatusChange = (listener: (status: ConnectionStatus) => void) => {
  statusListeners.push(listener);
  listener(currentServerStatus);
  return () => {
    const idx = statusListeners.indexOf(listener);
    if (idx >= 0) statusListeners.splice(idx, 1);
  };
};

const notifyStatus = (status: ConnectionStatus) => {
  if (currentServerStatus !== status) {
    currentServerStatus = status;
    statusListeners.forEach(fn => fn(status));
  }
};

// Health check function to verify server availability
export async function checkServerHealth(): Promise<boolean> {
  try {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 4000);
    const res = await fetch('/api/health', { signal: controller.signal });
    clearTimeout(timeout);
    if (res.ok) {
      notifyStatus('online');
      return true;
    }
  } catch {
    // Network or server error
  }
  notifyStatus('offline');
  return false;
}

// Auto-run health check every 8 seconds
if (typeof window !== 'undefined') {
  setInterval(checkServerHealth, 8000);
  window.addEventListener('online', () => checkServerHealth());
  window.addEventListener('offline', () => notifyStatus('offline'));
}

// Realtime SSE event listener management for seamless live synchronization
type RealtimeCallback = (payload: any) => void;

interface ChannelSubscription {
  channelName: string;
  postgresHandlers: Array<{ table: string; callback: RealtimeCallback }>;
  broadcastHandlers: Array<{ event: string; callback: RealtimeCallback }>;
}

const activeChannels: Map<string, ChannelSubscription> = new Map();
let eventSource: EventSource | null = null;

function setupEventSource() {
  if (typeof window === 'undefined') return;
  if (eventSource) return;

  try {
    eventSource = new EventSource('/api/events');

    eventSource.onopen = () => {
      notifyStatus('online');
    };

    eventSource.onmessage = (e) => {
      notifyStatus('online');
      try {
        const data = JSON.parse(e.data);
        if (data.type === 'postgres_changes') {
          activeChannels.forEach(sub => {
            sub.postgresHandlers.forEach(handler => {
              if (handler.table === '*' || handler.table === data.table) {
                handler.callback(data);
              }
            });
          });
        } else if (data.type === 'broadcast') {
          activeChannels.forEach(sub => {
            sub.broadcastHandlers.forEach(handler => {
              if (handler.event === '*' || handler.event === data.event) {
                handler.callback(data);
              }
            });
          });
        }
      } catch (err) {
        console.error('Error parsing SSE event:', err);
      }
    };

    eventSource.onerror = () => {
      notifyStatus('offline');
      if (eventSource) {
        eventSource.close();
        eventSource = null;
        // Reconnect after delay
        setTimeout(setupEventSource, 3000);
      }
    };
  } catch (err) {
    notifyStatus('offline');
    console.error('Failed to initialize EventSource:', err);
  }
}

class RealtimeChannel {
  channelName: string;
  private sub: ChannelSubscription;

  constructor(name: string) {
    this.channelName = name;
    if (!activeChannels.has(name)) {
      activeChannels.set(name, {
        channelName: name,
        postgresHandlers: [],
        broadcastHandlers: []
      });
    }
    this.sub = activeChannels.get(name)!;
  }

  on(type: 'postgres_changes' | 'broadcast', filterOrEvent: any, callback?: RealtimeCallback) {
    if (type === 'postgres_changes') {
      const table = filterOrEvent?.table || '*';
      const cb = callback || filterOrEvent;
      if (typeof cb === 'function') {
        this.sub.postgresHandlers.push({ table, callback: cb });
      }
    } else if (type === 'broadcast') {
      const event = filterOrEvent?.event || (typeof filterOrEvent === 'string' ? filterOrEvent : '*');
      const cb = callback;
      if (typeof cb === 'function') {
        this.sub.broadcastHandlers.push({ event, callback: cb });
      }
    }
    return this;
  }

  subscribe(callback?: (status: string) => void) {
    setupEventSource();
    if (callback) {
      setTimeout(() => callback('SUBSCRIBED'), 10);
    }
    return this;
  }

  async send(message: { type: string; event: string; payload: any }): Promise<any> {
    try {
      const res = await fetch('/api/broadcast', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(message)
      });
      return await res.json();
    } catch (err) {
      console.error('Error sending broadcast:', err);
      return null;
    }
  }
}

export const supabase = {
  channel: (name: string) => new RealtimeChannel(name),
  removeChannel: (channel: any) => {
    if (channel && channel.channelName) {
      activeChannels.delete(channel.channelName);
    }
  }
};

/* ==========================================
   1. EMPLOYEES SERVICES
   ========================================== */
export async function getSupabaseEmployees(): Promise<Employee[] | null> {
  try {
    const res = await fetch('/api/employees');
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const data = await res.json();
    return data || [];
  } catch (err) {
    console.error('Server database - could not fetch employees:', err);
    return null;
  }
}

export async function upsertSupabaseEmployee(employee: Employee): Promise<boolean> {
  try {
    const res = await fetch('/api/employees', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(employee)
    });
    return res.ok;
  } catch (err) {
    console.error('Server database - could not upsert employee:', err);
    return false;
  }
}

export async function deleteSupabaseEmployee(employeeId: string): Promise<boolean> {
  try {
    const res = await fetch(`/api/employees/${encodeURIComponent(employeeId)}`, {
      method: 'DELETE'
    });
    return res.ok;
  } catch (err) {
    console.error('Server database - could not delete employee:', err);
    return false;
  }
}

export async function clearAllSupabaseEmployees(): Promise<boolean> {
  try {
    const res = await fetch('/api/employees', {
      method: 'DELETE'
    });
    return res.ok;
  } catch (err) {
    console.error('Server database - could not clear employees:', err);
    return false;
  }
}

/* ==========================================
   2. ATTENDANCE LOGS SERVICES
   ========================================== */
export async function getSupabaseLogs(): Promise<AttendanceLog[] | null> {
  try {
    const res = await fetch('/api/logs');
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const data = await res.json();
    return data || [];
  } catch (err) {
    console.error('Server database - could not fetch logs:', err);
    return null;
  }
}

export async function upsertSupabaseLog(log: AttendanceLog): Promise<boolean> {
  try {
    const res = await fetch('/api/logs', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(log)
    });
    return res.ok;
  } catch (err) {
    console.error('Server database - could not upsert log:', err);
    return false;
  }
}

export async function deleteSupabaseLog(logId: string): Promise<boolean> {
  try {
    const res = await fetch(`/api/logs/${encodeURIComponent(logId)}`, {
      method: 'DELETE'
    });
    return res.ok;
  } catch (err) {
    console.error('Server database - could not delete log:', err);
    return false;
  }
}

export async function clearAllSupabaseLogs(): Promise<boolean> {
  try {
    const res = await fetch('/api/logs', {
      method: 'DELETE'
    });
    return res.ok;
  } catch (err) {
    console.error('Server database - could not clear logs:', err);
    return false;
  }
}

/* ==========================================
   3. LEAVE REQUESTS SERVICES
   ========================================== */
export async function getSupabaseLeaves(): Promise<LeaveRequest[] | null> {
  try {
    const res = await fetch('/api/leaves');
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const data = await res.json();
    return data || [];
  } catch (err) {
    console.error('Server database - could not fetch leaves:', err);
    return null;
  }
}

export async function upsertSupabaseLeave(leave: LeaveRequest): Promise<boolean> {
  try {
    const res = await fetch('/api/leaves', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(leave)
    });
    return res.ok;
  } catch (err) {
    console.error('Server database - could not upsert leave:', err);
    return false;
  }
}

export async function clearAllSupabaseLeaves(): Promise<boolean> {
  try {
    const res = await fetch('/api/leaves', {
      method: 'DELETE'
    });
    return res.ok;
  } catch (err) {
    console.error('Server database - could not clear leaves:', err);
    return false;
  }
}

/* ==========================================
   4. STORE LOCATION SERVICES
   ========================================== */
export async function getSupabaseStoreLocation(): Promise<StoreLocation | null> {
  try {
    const res = await fetch('/api/store-location');
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const data = await res.json();
    return data || null;
  } catch (err) {
    console.error('Server database - could not fetch store location:', err);
    return null;
  }
}

export async function updateSupabaseStoreLocation(location: StoreLocation): Promise<boolean> {
  try {
    const res = await fetch('/api/store-location', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(location)
    });
    return res.ok;
  } catch (err) {
    console.error('Server database - could not update store location:', err);
    return false;
  }
}

/* ==========================================
   5. FCM TOKENS SERVICES
   ========================================== */
export async function saveSupabaseFcmToken(employeeId: string, token: string): Promise<boolean> {
  try {
    const res = await fetch('/api/fcm-tokens', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ employeeId, token })
    });
    return res.ok;
  } catch (err) {
    console.error('Server database - could not save FCM token:', err);
    localStorage.setItem(`fcm_token_${employeeId}`, token);
    return false;
  }
}

export async function getSupabaseFcmTokens(employeeId?: string): Promise<string[]> {
  try {
    const url = employeeId ? `/api/fcm-tokens?employeeId=${encodeURIComponent(employeeId)}` : '/api/fcm-tokens';
    const res = await fetch(url);
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const data = await res.json();
    return data || [];
  } catch (err) {
    console.error('Server database - could not retrieve FCM tokens:', err);
    if (employeeId) {
      const stored = localStorage.getItem(`fcm_token_${employeeId}`);
      return stored ? [stored] : [];
    }
    return [];
  }
}

export async function deleteSupabaseFcmToken(token: string): Promise<boolean> {
  try {
    const res = await fetch(`/api/fcm-tokens?token=${encodeURIComponent(token)}`, {
      method: 'DELETE'
    });
    return res.ok;
  } catch (err) {
    console.error('Server database - could not delete FCM token:', err);
    return false;
  }
}

/* ==========================================
   6. POSITIONS SERVICES
   ========================================== */
export async function getSupabasePositions(): Promise<string[] | null> {
  try {
    const res = await fetch('/api/positions');
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const data = await res.json();
    return data || [];
  } catch (err) {
    console.error('Server database - could not fetch positions:', err);
    return null;
  }
}

export async function addSupabasePosition(name: string): Promise<boolean> {
  try {
    const res = await fetch('/api/positions', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name })
    });
    return res.ok;
  } catch (err) {
    console.error('Server database - could not add position:', err);
    return false;
  }
}

export async function deleteSupabasePosition(name: string): Promise<boolean> {
  try {
    const res = await fetch(`/api/positions/${encodeURIComponent(name)}`, {
      method: 'DELETE'
    });
    return res.ok;
  } catch (err) {
    console.error('Server database - could not delete position:', err);
    return false;
  }
}

/* ==========================================
   7. ALARM SETTINGS SERVICES
   ========================================== */
export async function getSupabaseAlarmSettings(): Promise<DbAlarmSettings | null> {
  try {
    const res = await fetch('/api/alarm-settings');
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const data = await res.json();
    return data || null;
  } catch (err) {
    console.error('Server database - could not fetch alarm settings:', err);
    return null;
  }
}

export async function updateSupabaseAlarmSettings(settings: DbAlarmSettings): Promise<boolean> {
  try {
    const res = await fetch('/api/alarm-settings', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(settings)
    });
    return res.ok;
  } catch (err) {
    console.error('Server database - could not update alarm settings:', err);
    return false;
  }
}
