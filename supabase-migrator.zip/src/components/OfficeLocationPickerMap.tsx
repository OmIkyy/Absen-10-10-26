import React, { useEffect, useRef, useState } from 'react';
import {
  Search,
  Compass,
  MapPin,
  ZoomIn,
  ZoomOut,
  Check,
  Layers,
  Store
} from 'lucide-react';

interface SearchResultItem {
  id: string;
  name: string;
  address: string;
  lat: number;
  lng: number;
  source?: string;
}

interface OfficeLocationPickerMapProps {
  latitude: number;
  longitude: number;
  radius: number;
  officeName?: string;
  onLocationChange: (lat: number, lng: number) => void;
  onPlaceSelected?: (name: string, address: string) => void;
}

let leafletPromise: Promise<any> | null = null;

function loadLeaflet(): Promise<any> {
  if (leafletPromise) return leafletPromise;

  leafletPromise = new Promise((resolve, reject) => {
    if ((window as any).L) {
      resolve((window as any).L);
      return;
    }

    const link = document.createElement('link');
    link.rel = 'stylesheet';
    link.href = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.css';
    link.crossOrigin = '';
    document.head.appendChild(link);

    const script = document.createElement('script');
    script.src = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.js';
    script.crossOrigin = '';
    script.onload = () => {
      resolve((window as any).L);
    };
    script.onerror = () => {
      reject(new Error('Gagal memuat peta interaktif. Periksa koneksi internet Anda.'));
    };
    document.head.appendChild(script);
  });

  return leafletPromise;
}

export const OfficeLocationPickerMap: React.FC<OfficeLocationPickerMapProps> = ({
  latitude,
  longitude,
  radius,
  officeName = 'Titik Kantor',
  onLocationChange,
  onPlaceSelected,
}) => {
  const mapContainerRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<any>(null);
  const markerRef = useRef<any>(null);
  const circleRef = useRef<any>(null);
  const activeTileLayerRef = useRef<any>(null);

  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  // Map layer mode: 'roadmap' (Google Maps Alami dengan nama toko & tempat) or 'hybrid' (Satelit + nama tempat)
  const [mapMode, setMapMode] = useState<'roadmap' | 'hybrid'>('roadmap');

  // Search places & stores state
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [isSearching, setIsSearching] = useState<boolean>(false);
  const [searchResults, setSearchResults] = useState<SearchResultItem[]>([]);
  const [showSearchResults, setShowSearchResults] = useState<boolean>(false);
  const [searchError, setSearchError] = useState<string | null>(null);
  const [geoLocating, setGeoLocating] = useState<boolean>(false);
  const [lastSelectedPlace, setLastSelectedPlace] = useState<{
    name: string;
    address: string;
  } | null>(null);

  // Initialize Map
  useEffect(() => {
    let isMounted = true;

    loadLeaflet()
      .then((L) => {
        if (!isMounted || !mapContainerRef.current) return;
        setLoading(false);

        if (!mapInstanceRef.current) {
          const map = L.map(mapContainerRef.current, {
            center: [latitude, longitude],
            zoom: 17,
            zoomControl: false,
            scrollWheelZoom: true,
          });

          mapInstanceRef.current = map;

          // Default layer: Google Maps Natural Roadmap (includes all Indonesian stores, shops, POIs, rukos, and landmarks)
          const googleRoadmapLayer = L.tileLayer(
            'https://mt{s}.google.com/vt/lyrs=m&x={x}&y={y}&z={z}',
            {
              subdomains: '0123',
              maxZoom: 20,
              attribution: '&copy; Google Maps &bull; Data Tempat & Toko Lengkap',
            }
          ).addTo(map);

          activeTileLayerRef.current = googleRoadmapLayer;

          // Modern Pin with pulse animation and store locator badge
          const customOfficeIcon = L.divIcon({
            className: 'custom-leaflet-office-pin',
            html: `
              <div class="relative flex items-center justify-center w-12 h-12 cursor-grab active:cursor-grabbing">
                <div class="absolute inset-0 rounded-full bg-rose-500/25 animate-ping"></div>
                <div class="relative flex items-center justify-center w-10 h-10 rounded-2xl bg-rose-600 text-white shadow-xl border-2 border-white ring-2 ring-rose-500/50">
                  <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z"></path>
                    <circle cx="12" cy="10" r="3"></circle>
                  </svg>
                </div>
              </div>
            `,
            iconSize: [48, 48],
            iconAnchor: [24, 24],
          });

          // Draggable Marker
          const marker = L.marker([latitude, longitude], {
            draggable: true,
            icon: customOfficeIcon,
            autoPan: true,
          }).addTo(map);

          markerRef.current = marker;

          // Geofence Circle
          const circle = L.circle([latitude, longitude], {
            color: '#4f46e5',
            fillColor: '#6366f1',
            fillOpacity: 0.18,
            weight: 2,
            dashArray: '5, 5',
            radius: radius || 50,
          }).addTo(map);

          circleRef.current = circle;

          // Marker drag events
          marker.on('drag', () => {
            const pos = marker.getLatLng();
            circle.setLatLng(pos);
          });

          marker.on('dragend', () => {
            const pos = marker.getLatLng();
            const newLat = parseFloat(pos.lat.toFixed(6));
            const newLng = parseFloat(pos.lng.toFixed(6));
            circle.setLatLng(pos);
            onLocationChange(newLat, newLng);
          });

          // Click anywhere on map to reposition marker
          map.on('click', (e: any) => {
            const newLat = parseFloat(e.latlng.lat.toFixed(6));
            const newLng = parseFloat(e.latlng.lng.toFixed(6));
            marker.setLatLng(e.latlng);
            circle.setLatLng(e.latlng);
            onLocationChange(newLat, newLng);
          });
        }
      })
      .catch((err) => {
        if (isMounted) {
          setError(err.message || 'Gagal memuat peta');
          setLoading(false);
        }
      });

    return () => {
      isMounted = false;
    };
  }, []);

  // Switch between Google Natural Roadmap and Google Hybrid Satellite (with store & street labels)
  const handleToggleMapMode = () => {
    if (!mapInstanceRef.current || !(window as any).L) return;
    const L = (window as any).L;
    const nextMode = mapMode === 'roadmap' ? 'hybrid' : 'roadmap';
    setMapMode(nextMode);

    if (activeTileLayerRef.current) {
      mapInstanceRef.current.removeLayer(activeTileLayerRef.current);
    }

    if (nextMode === 'hybrid') {
      // Google Hybrid: Real satellite photo + all store names, POIs, and street labels
      const hybridLayer = L.tileLayer(
        'https://mt{s}.google.com/vt/lyrs=y&x={x}&y={y}&z={z}',
        {
          subdomains: '0123',
          maxZoom: 20,
          attribution: '&copy; Google Maps Satelit &bull; Foto Udara & Nama Toko',
        }
      ).addTo(mapInstanceRef.current);
      activeTileLayerRef.current = hybridLayer;
    } else {
      // Google Natural Roadmap: crisp vector roadmap with all Indonesian stores, shops, rukos, and landmarks
      const roadmapLayer = L.tileLayer(
        'https://mt{s}.google.com/vt/lyrs=m&x={x}&y={y}&z={z}',
        {
          subdomains: '0123',
          maxZoom: 20,
          attribution: '&copy; Google Maps &bull; Data Tempat & Toko Lengkap',
        }
      ).addTo(mapInstanceRef.current);
      activeTileLayerRef.current = roadmapLayer;
    }
  };

  // Sync marker and circle whenever lat/lng props change
  useEffect(() => {
    if (markerRef.current && circleRef.current && mapInstanceRef.current) {
      const currentMarkerPos = markerRef.current.getLatLng();
      const diffLat = Math.abs(currentMarkerPos.lat - latitude);
      const diffLng = Math.abs(currentMarkerPos.lng - longitude);

      if (diffLat > 0.00001 || diffLng > 0.00001) {
        markerRef.current.setLatLng([latitude, longitude]);
        circleRef.current.setLatLng([latitude, longitude]);
        mapInstanceRef.current.panTo([latitude, longitude], { animate: true });
      }
    }
  }, [latitude, longitude]);

  // Sync radius circle whenever radius prop changes
  useEffect(() => {
    if (circleRef.current) {
      circleRef.current.setRadius(radius || 50);
    }
  }, [radius]);

  // Search Address or Business/Shop name via Google Places API (New)
  const handleSearchPlaces = async (e: React.FormEvent) => {
    e.preventDefault();
    const query = searchQuery.trim();
    if (!query) return;

    setIsSearching(true);
    setSearchError(null);
    try {
      const res = await fetch(`/api/places/search?q=${encodeURIComponent(query)}`);
      if (res.ok) {
        const data = await res.json();
        const items: SearchResultItem[] = data.results || [];
        setSearchResults(items);
        setShowSearchResults(true);
        if (items.length === 0) {
          setSearchError(
            `Tidak ditemukan hasil untuk "${query}". Coba ketik nama jalan, kelurahan, atau kecamatan terdekat.`
          );
        }
      } else {
        setSearchError('Server pencarian sedang sibuk. Silakan coba kembali.');
      }
    } catch (err) {
      console.error('Search error:', err);
      setSearchError('Koneksi pencarian terputus. Pastikan perangkat terhubung ke internet.');
    } finally {
      setIsSearching(false);
    }
  };

  // Select place from search results
  const handleSelectSearchResult = (item: SearchResultItem) => {
    const newLat = parseFloat(item.lat.toFixed(6));
    const newLng = parseFloat(item.lng.toFixed(6));

    if (mapInstanceRef.current && markerRef.current && circleRef.current) {
      markerRef.current.setLatLng([newLat, newLng]);
      circleRef.current.setLatLng([newLat, newLng]);
      mapInstanceRef.current.setView([newLat, newLng], 18, { animate: true });
    }

    onLocationChange(newLat, newLng);
    setLastSelectedPlace({ name: item.name, address: item.address });
    setShowSearchResults(false);
  };

  // Apply selected place name and address to form
  const handleApplyPlaceToForm = () => {
    if (lastSelectedPlace && onPlaceSelected) {
      onPlaceSelected(lastSelectedPlace.name, lastSelectedPlace.address);
    }
  };

  // Get current device GPS location
  const handleGetDeviceLocation = () => {
    if (!navigator.geolocation) {
      alert('Perangkat Anda tidak mendukung fitur Geolocation GPS.');
      return;
    }

    setGeoLocating(true);
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setGeoLocating(false);
        const newLat = parseFloat(pos.coords.latitude.toFixed(6));
        const newLng = parseFloat(pos.coords.longitude.toFixed(6));

        if (mapInstanceRef.current && markerRef.current && circleRef.current) {
          markerRef.current.setLatLng([newLat, newLng]);
          circleRef.current.setLatLng([newLat, newLng]);
          mapInstanceRef.current.setView([newLat, newLng], 18, { animate: true });
        }

        onLocationChange(newLat, newLng);
      },
      (err) => {
        setGeoLocating(false);
        alert(`Gagal mengambil GPS HP: ${err.message}. Pastikan izin lokasi aktif.`);
      },
      { enableHighAccuracy: true, timeout: 10000, maximumAge: 0 }
    );
  };

  const handleZoomIn = () => {
    if (mapInstanceRef.current) mapInstanceRef.current.zoomIn();
  };

  const handleZoomOut = () => {
    if (mapInstanceRef.current) mapInstanceRef.current.zoomOut();
  };

  const handleCenterOnPin = () => {
    if (mapInstanceRef.current) {
      mapInstanceRef.current.setView([latitude, longitude], 17, { animate: true });
    }
  };

  return (
    <div className="relative w-full rounded-2xl overflow-hidden border border-slate-200 shadow-sm bg-slate-100 flex flex-col">
      {/* Top Map Toolbar: Google Places Search & Action Header */}
      <div className="p-2.5 bg-white border-b border-slate-200 flex flex-col sm:flex-row gap-2 items-center justify-between z-10">
        {/* Search Input Form (Google Places Powered) */}
        <form
          onSubmit={handleSearchPlaces}
          className="relative flex-1 w-full flex items-center gap-1.5"
        >
          <div className="relative flex-1">
            <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              placeholder="Cari nama toko, ruko, kantor, tempat (Contoh: DG Komputer, Grand Indonesia, atau jalan)..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-8 pr-3 py-1.5 text-xs text-slate-800 placeholder-slate-400 outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600 tracking-normal normal-case font-medium"
            />
          </div>
          <button
            type="submit"
            disabled={isSearching}
            className="bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white font-bold text-xs px-3.5 py-1.5 rounded-xl transition-all shrink-0 cursor-pointer shadow-2xs flex items-center gap-1"
          >
            {isSearching ? (
              <span className="flex items-center gap-1">
                <span className="w-3 h-3 border-2 border-white border-t-transparent rounded-full animate-spin"></span>
                <span>Mencari...</span>
              </span>
            ) : (
              <span>Cari Tempat</span>
            )}
          </button>
        </form>

        {/* Action Buttons: Roadmap / Hybrid Satellite toggle, GPS, Recenter */}
        <div className="flex items-center gap-1.5 self-end sm:self-auto shrink-0">
          <button
            type="button"
            onClick={handleToggleMapMode}
            title={
              mapMode === 'roadmap'
                ? 'Beralih ke Peta Satelit Asli'
                : 'Beralih ke Peta Normal (Google Maps)'
            }
            className={`px-2.5 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1 cursor-pointer active:scale-95 shadow-2xs border ${
              mapMode === 'hybrid'
                ? 'bg-indigo-600 text-white border-indigo-700'
                : 'bg-slate-100 hover:bg-slate-200 text-slate-700 border-slate-200'
            }`}
          >
            <Layers className="w-3.5 h-3.5" />
            <span>{mapMode === 'hybrid' ? 'Peta Satelit' : 'Peta Alami'}</span>
          </button>

          <button
            type="button"
            onClick={handleGetDeviceLocation}
            disabled={geoLocating}
            title="Gunakan titik GPS saya saat ini"
            className="bg-emerald-50 hover:bg-emerald-100 text-emerald-700 border border-emerald-200 px-2.5 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1 cursor-pointer active:scale-95 shadow-2xs"
          >
            <Compass className={`w-3.5 h-3.5 ${geoLocating ? 'animate-spin' : ''}`} />
            <span>{geoLocating ? 'Melacak...' : 'GPS Saya'}</span>
          </button>

          <button
            type="button"
            onClick={handleCenterOnPin}
            title="Pusatkan peta ke pin kantor"
            className="bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-200 px-2.5 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1 cursor-pointer active:scale-95 shadow-2xs"
          >
            <MapPin className="w-3.5 h-3.5 text-rose-600" />
            <span>Ke Pin</span>
          </button>
        </div>
      </div>

      {/* Search Results Dropdown */}
      {showSearchResults && (
        <div className="absolute top-[52px] left-2 right-2 bg-white rounded-2xl shadow-2xl border border-slate-200 p-2.5 z-30 max-h-72 overflow-y-auto space-y-1 animate-fadeIn">
          <div className="flex items-center justify-between px-2 py-1 border-b border-slate-100 text-[10px] font-bold text-slate-400 uppercase tracking-wider">
            <span className="flex items-center gap-1.5 text-indigo-700">
              <Store className="w-3.5 h-3.5" />
              <span>Hasil Pencarian Tempat & Toko</span>
            </span>
            <button
              type="button"
              onClick={() => setShowSearchResults(false)}
              className="text-slate-400 hover:text-slate-600 cursor-pointer font-bold"
            >
              ✕ Tutup
            </button>
          </div>

          {searchError && (
            <div className="p-3 bg-amber-50 text-amber-800 rounded-xl text-xs font-semibold">
              {searchError}
            </div>
          )}

          {searchResults.map((item) => (
            <button
              key={item.id}
              type="button"
              onClick={() => handleSelectSearchResult(item)}
              className="w-full text-left p-2.5 rounded-xl hover:bg-indigo-50/80 transition-colors text-xs text-slate-700 font-medium flex items-start gap-2.5 cursor-pointer border border-transparent hover:border-indigo-100 group"
            >
              <div className="w-8 h-8 rounded-lg bg-indigo-100 text-indigo-700 flex items-center justify-center shrink-0 mt-0.5 group-hover:bg-indigo-600 group-hover:text-white transition-colors">
                <Store className="w-4 h-4" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between gap-2">
                  <span className="font-extrabold text-slate-900 text-xs block truncate group-hover:text-indigo-700">
                    {item.name}
                  </span>
                  <span className="text-[9px] font-bold px-1.5 py-0.5 rounded bg-blue-50 text-blue-700 border border-blue-200 shrink-0">
                    Google Places
                  </span>
                </div>
                <p className="text-[11px] text-slate-500 line-clamp-2 mt-0.5 leading-snug">
                  {item.address}
                </p>
                <span className="text-[9px] font-mono text-slate-400 block mt-1">
                  {item.lat.toFixed(6)}, {item.lng.toFixed(6)}
                </span>
              </div>
            </button>
          ))}
        </div>
      )}

      {/* Notification banner when place is selected */}
      {lastSelectedPlace && onPlaceSelected && (
        <div className="bg-indigo-50 border-b border-indigo-100 px-3 py-2 flex items-center justify-between gap-2 z-10">
          <div className="flex items-center gap-2 min-w-0">
            <span className="text-base select-none">🏬</span>
            <div className="truncate text-xs">
              <span className="font-bold text-indigo-900 truncate block">
                {lastSelectedPlace.name}
              </span>
              <span className="text-[10px] text-slate-500 truncate block">
                {lastSelectedPlace.address}
              </span>
            </div>
          </div>
          <button
            type="button"
            onClick={handleApplyPlaceToForm}
            className="bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-[11px] px-3 py-1.5 rounded-lg shrink-0 cursor-pointer shadow-xs active:scale-95 transition-all flex items-center gap-1"
          >
            <Check className="w-3.5 h-3.5" />
            <span>Terapkan Nama & Alamat</span>
          </button>
        </div>
      )}

      {/* Main Map Container */}
      <div className="relative w-full h-[400px] bg-slate-100">
        {loading && (
          <div className="absolute inset-0 z-20 flex flex-col items-center justify-center bg-slate-50/90 text-slate-600 gap-3">
            <div className="w-8 h-8 rounded-full border-4 border-slate-200 border-t-indigo-600 animate-spin"></div>
            <span className="text-xs font-bold">Memuat Peta Alami Google Maps...</span>
          </div>
        )}

        {error && (
          <div className="absolute inset-0 z-20 flex flex-col items-center justify-center bg-rose-50/95 text-rose-700 p-6 text-center gap-2">
            <span className="text-xs font-bold uppercase tracking-wider">Kesalahan Memuat Peta</span>
            <p className="text-xs text-slate-500 max-w-xs">{error}</p>
          </div>
        )}

        {/* Map Div */}
        <div ref={mapContainerRef} className="w-full h-full z-0 cursor-crosshair" />

        {/* Floating Zoom Controls */}
        <div className="absolute right-3 bottom-12 z-10 flex flex-col gap-1.5 shadow-md">
          <button
            type="button"
            onClick={handleZoomIn}
            className="w-8 h-8 rounded-xl bg-white hover:bg-slate-50 text-slate-700 flex items-center justify-center border border-slate-200 transition-all active:scale-90 cursor-pointer shadow-sm"
            title="Zoom Masuk (+)"
          >
            <ZoomIn className="w-4 h-4" />
          </button>
          <button
            type="button"
            onClick={handleZoomOut}
            className="w-8 h-8 rounded-xl bg-white hover:bg-slate-50 text-slate-700 flex items-center justify-center border border-slate-200 transition-all active:scale-90 cursor-pointer shadow-sm"
            title="Zoom Keluar (-)"
          >
            <ZoomOut className="w-4 h-4" />
          </button>
        </div>

        {/* Bottom Floating Info Pill */}
        <div className="absolute bottom-3 left-3 right-14 z-10 flex items-center gap-2 pointer-events-none">
          <div className="bg-slate-900/85 backdrop-blur-md text-white px-3 py-1.5 rounded-xl text-[11px] font-medium shadow-lg flex items-center gap-2 truncate pointer-events-auto border border-white/10">
            <span className="inline-block w-2 h-2 rounded-full bg-emerald-400 animate-pulse shrink-0"></span>
            <span className="font-mono font-bold text-emerald-300">
              {latitude.toFixed(6)}, {longitude.toFixed(6)}
            </span>
            <span className="text-slate-400">|</span>
            <span className="text-indigo-200 font-bold">
              Radius: {radius || 50} meter
            </span>
            <span className="text-slate-400">|</span>
            <span className="text-amber-300 font-semibold capitalize text-[10px]">
              {mapMode === 'hybrid' ? 'Satelit + Label Toko' : 'Google Maps Alami'}
            </span>
          </div>
        </div>
      </div>

      {/* Bottom Interactive Guidance Helper */}
      <div className="px-3.5 py-2.5 bg-slate-50 border-t border-slate-200 text-[11px] text-slate-600 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          <span className="text-sm select-none">📍</span>
          <span>
            <strong>Peta Google Maps Alami:</strong> Menampilkan semua nama toko, ruko, restoran, minimarket, dan bangunan secara nyata. Anda dapat mengklik langsung toko Anda di peta atau menggeser pin merah dengan presisi.
          </span>
        </div>
      </div>
    </div>
  );
};
